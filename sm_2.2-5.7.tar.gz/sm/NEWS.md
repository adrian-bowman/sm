# sm 2.3-5.7

* The package can now be installed on systems which do not have the tcltk package available.  Some minor big fixes are also included.

