# sm 2.2-6.0

* Details

# sm 2.2-5.7

* The package can now be installed on systems which do not have the tcltk package available.  Some minor big fixes are also included.

